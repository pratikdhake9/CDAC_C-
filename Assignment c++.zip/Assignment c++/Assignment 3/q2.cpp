/*
Q2. Create a class Student with:
 roll, name, marks
 Parameterized constructor
 Destructor that prints "Destroying student …"
Tasks:
1. Create an array of 3 Student objects.
2. Write all student details to a file "students.txt".
3. Read the file again and print contents.
4. Explain constructor/destructor call sequence for array of objects.
*/

#include <iostream>
#include <cstdio>
using namespace std;

class Student {
private:
    int roll;
    string name;
    float marks;
public:
    Student(int r, string n, float m) {
        roll = r;
        name = n;
        marks = m;
    }
    void writeToFile(FILE *fp) {
        fprintf(fp,"%d %s %.2f\n", roll, name.c_str(), marks);
    }

    void display() {
        cout << roll << " " << name << " " << marks << endl;
    }
    ~Student() {
        cout << "Destroying student " << name << endl;
    }
};
int main() {
    Student s[3] = {
        Student(1,"Rahul",85),
        Student(2,"Amit",90),
        Student(3,"Neha",88)
    };
    FILE *fp = fopen("students.txt","w");

    for(int i=0;i<3;i++)
        s[i].writeToFile(fp);
    fclose(fp);
    cout<<"Data written to file"<<endl;
    fp = fopen("students.txt","r");

    int r;
    char n[50];
    float m;
    cout<<"Reading from file:"<<endl;
    while(fscanf(fp,"%d %s %f",&r,n,&m)!=EOF)
        cout<<r<<" "<<n<<" "<<m<<endl;
    fclose(fp);
    return 0;
}