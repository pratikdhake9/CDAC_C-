/*
Q4. Write a program to divide two integers.
Requirements:
1. Throw a custom exception DivideByZero when denominator = 0.
2. Use nested try-catch where:
o Inner catch prints "Inside inner catch"
o Rethrows the exception
o Outer catch prints "Handled in outer catch"
3. Use an exception specification list on a function that may throw only DivideByZero.
*/


#include <iostream>
using namespace std;

class DivideByZero
{
public:
    void message()
    {
        cout << "Error: Division by Zero!" << endl;
    }
};
int divide(int a, int b) throw(DivideByZero)
{
    if(b == 0)
    {
        throw DivideByZero();
    }

    return a / b;
}

int main()
{
    int a, b;

    cout << "Enter two integers: ";
    cin >> a >> b;

    try
    {
        try
        {
            int result = divide(a, b);
            cout << "Result = " << result << endl;
        }
        catch(DivideByZero e)
        {
            cout << "Inside inner catch" << endl;
            e.message();
            throw; 
        }
    }
    catch(DivideByZero)
    {
        cout << "Handled in outer catch" << endl;
    }

    return 0;
}