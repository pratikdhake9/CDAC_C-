/*
Q7. Implement your own String class (char pointer) with:
 Constructor
 Copy constructor
 Destructor
 Assignment operator
 operator+ for concatenation
 operator<< / operator>>
Tasks:
1. Input two strings using your class.
2. Concatenate them using s3 = s1 + s2;
3. Print all three strings.
4. Demonstrate memory handling (deep copy)
*/

#include <iostream>
using namespace std;

class String
{
    char *str;

public:
    String(const char *s = "")
    {
        int len = 0;
        while(s[len] != '\0')
            len++;

        str = new char[len + 1];

        for(int i = 0; i <= len; i++)
            str[i] = s[i];
    }
    String(const String &s)
    {
        int len = 0;
        while(s.str[len] != '\0')
            len++;

        str = new char[len + 1];

        for(int i = 0; i <= len; i++)
            str[i] = s.str[i];
    }
    ~String()
    {
        delete[] str;
    }
    String& operator=(const String &s)
    {
        if(this != &s)
        {
            delete[] str;

            int len = 0;
            while(s.str[len] != '\0')
                len++;

            str = new char[len + 1];

            for(int i = 0; i <= len; i++)
                str[i] = s.str[i];
        }

        return *this;
    }
    String operator+(const String &s)
    {
        int len1 = 0, len2 = 0;

        while(str[len1] != '\0') len1++;
        while(s.str[len2] != '\0') len2++;

        char *temp = new char[len1 + len2 + 1];

        int i;
        for(i = 0; i < len1; i++)
            temp[i] = str[i];

        for(int j = 0; j <= len2; j++)
            temp[i + j] = s.str[j];

        String result(temp);
        delete[] temp;

        return result;
    }
    friend istream& operator>>(istream &in, String &s)
    {
        char temp[100];
        in >> temp;

        delete[] s.str;

        int len = 0;
        while(temp[len] != '\0')
            len++;

        s.str = new char[len + 1];

        for(int i = 0; i <= len; i++)
            s.str[i] = temp[i];

        return in;
    }
    friend ostream& operator<<(ostream &out, String &s)
    {
        out << s.str;
        return out;
    }
};

int main()
{
    String s1, s2, s3;

    cout << "Enter first string: ";
    cin >> s1;

    cout << "Enter second string: ";
    cin >> s2;

    s3 = s1 + s2;

    cout << "\nString 1: " << s1 << endl;
    cout << "String 2: " << s2 << endl;
    cout << "Concatenated: " << s3 << endl;

    return 0;
}
