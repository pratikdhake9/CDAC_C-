/*
Q6. Create a Vector class (not std::vector) with:
 A dynamic int array
 Size variable
 Overloaded operator[] to access elements
 Overloaded operator() to return sum of all elements
Tasks:
1. Initialize an object using aggregate initialization (ONLY if suitable).
2. Demonstrate:
3. v[2] = 50;
4. cout << v( ); // should compute sum
5. Explain difference between index and function-call operators
*/

#include <iostream>
using namespace std;

class Vector
{
public:
    int arr[5];  
    int size;

    int& operator[](int index)
    {
        return arr[index];
    }
    int operator()()
    {
        int sum = 0;

        for(int i = 0; i < size; i++)
        {
            sum += arr[i];
        }

        return sum;
    }
};

int main()
{
    Vector v = {{10,20,30,40,50},5};
    v[2] = 50;

    cout << "Element at index 2: " << v[2] << endl;
    cout << "Sum of elements: " << v() << endl;

    return 0;
}