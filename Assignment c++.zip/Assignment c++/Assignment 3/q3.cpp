/*
Q3. Create a Matrix class using dynamic 2D allocation.
Implement the following:
 operator>> to input matrix
 operator<< to display matrix
 operator+ for matrix addition
 operator== to check equality
Tasks:
1. Create two matrices using cin >> m1 >> m2;
2. Add them: m3 = m1 + m2;
3. Compare matrices using if(m1 == m2)
4. Deallocate memory in destructor.
*/
#include <iostream>
using namespace std;

class Matrix {
    int rows, cols;
    int **arr;
public:
    Matrix(int r = 0, int c = 0) {
        rows = r;
        cols = c;

        if (rows > 0 && cols > 0) {
            arr = new int*[rows];
            for (int i = 0; i < rows; i++) {
                arr[i] = new int[cols];
            }
        } else {
            arr = NULL;
        }
    }
    ~Matrix() {
        if (arr != NULL) {
            for (int i = 0; i < rows; i++) {
                delete[] arr[i];
            }
            delete[] arr;
        }
    }
    friend istream& operator>>(istream &in, Matrix &m) {
        cout << "Enter elements:\n";
        for (int i = 0; i < m.rows; i++) {
            for (int j = 0; j < m.cols; j++) {
                in >> m.arr[i][j];
            }
        }
        return in;
    }

    // Output operator <<
    friend ostream& operator<<(ostream &out, Matrix &m) {
        for (int i = 0; i < m.rows; i++) {
            for (int j = 0; j < m.cols; j++) {
                out << m.arr[i][j] << " ";
            }
            out << endl;
        }
        return out;
    }
    Matrix operator+(Matrix &m) {
        Matrix temp(rows, cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                temp.arr[i][j] = arr[i][j] + m.arr[i][j];
            }
        }
        return temp;
    }
    bool operator==(Matrix &m) {
        if (rows != m.rows || cols != m.cols)
            return false;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (arr[i][j] != m.arr[i][j])
                    return false;
            }
        }
        return true;
    }
};
int main() {
    int r, c;
    cout << "Enter rows and columns: ";
    cin >> r >> c;

    Matrix m1(r, c), m2(r, c), m3(r, c);
    cin >> m1 >> m2;

    m3 = m1 + m2;
    cout << "\nMatrix 1:\n" << m1;
    cout << "\nMatrix 2:\n" << m2;

    cout << "\nAddition Result:\n" << m3;
    if (m1 == m2)
        cout << "\nMatrices are Equal\n";
    else
        cout << "\nMatrices are Not Equal\n";

    return 0;
}