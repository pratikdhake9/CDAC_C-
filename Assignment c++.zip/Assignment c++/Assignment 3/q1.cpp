/*
Q1. Create a class Employee with:
 int id
 string name
 mutable int accessCount
 A const member function display() that increments accessCount
 A user-defined copy constructor (deep copy where applicable)
 Show difference between:
o Shallow copy
o Deep copy
o Default copy constructor
o Your user-defined copy constructor
Tasks:
1. Create object e1, call display() multiple times.
2. Create e2 = e1; and prove whether copying was shallow or deep.
3. Explain why display() must be const and why accessCount must be mutable.
*/


#include <iostream>
using namespace std;
class Employee {
private:
    int id;
    string name;
    mutable int accessCount;

public:
    Employee(int i, string n) {
        id = i;
        name = n;
        accessCount = 0;
    }

    Employee(const Employee &e) {
        id = e.id;
        name = e.name;
        accessCount = e.accessCount;
        cout << "User-defined Copy Constructor Called" << endl;
    }
    void display() const {
        accessCount++;  
        cout << "ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Access Count: " << accessCount << endl;
        cout << endl;
    }
};

int main() {
    Employee e1(101,"Rahul");
    e1.display();
    e1.display();
    e1.display();
    Employee e2 = e1;
    cout<<"Displaying e2"<<endl;
    e2.display();
    return 0;
}