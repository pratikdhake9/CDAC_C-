/*
Q5. Create a class Number with:
 Private int value
 A friend function to compare two objects (operator>)
 A friend class Inspector that can read private data
 Overload:
o Pre-increment ++n
o Post-increment n++
o Assignment operator =
Tasks:
1. Show difference between pre & post increment.
2. Use Inspector to print private members.
3. Compare objects using friend function.
*/

#include <iostream>
using namespace std;

class Number;
class Inspector;
bool operator>(const Number &, const Number &);

class Number
{
private:
    int value;

public:
    Number(int v = 0)
    {
        value = v;
    }
    Number& operator=(const Number &n)
    {
        value = n.value;
        return *this;
    }
    Number& operator++()
    {
        value = value + 1;
        return *this;
    }
    Number operator++(int)
    {
        Number temp(value);
        value++;
        return temp;
    }

    friend bool operator>(const Number &, const Number &);
    friend class Inspector;
};
bool operator>(const Number &a, const Number &b)
{
    return a.value > b.value;
}
class Inspector
{
public:
    void display(Number a, Number b)
    {
        cout << "Value1 = " << a.value << endl;
        cout << "Value2 = " << b.value << endl;
    }
};

int main()
{
    Number n1(5), n2(10), n3;
    Inspector obj;
    cout << "Initial Values:\n";
    obj.display(n1, n2);
    n3 = n1;
    cout << "\nAfter Assignment n3 = n1:\n";
    obj.display(n3, n2);
    cout << "\nPre Increment (++n1):\n";
    ++n1;
    obj.display(n1, n2);
    cout << "\nPost Increment (n1++):\n";
    n1++;
    obj.display(n1, n2);
    if(n2 > n1)
        cout << "\nn2 is greater than n1\n";
    else
        cout << "\nn1 is greater or equal to n2\n";
    return 0;
}