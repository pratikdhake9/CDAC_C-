/*Q1. Create a class called Student with the following private data members:

1.name (string):to store the name of the student.
2.rollNumber(int):to store the rollnumber of the student.
3.marks(float): to store the marks obtained by the student.
4.grade(char):to store the grade calculated based on the marks. Implement getter and setter member functions for each data member
Create a member function calculateGrade() that calculates the grade based on the following grading scale:
A: 90-100
B: 80-89
C: 70-79
D: 60-69
F: Below 60
Implement a menu-driven program in the main() function with the following options:
1.Accept Information
2.Display information
3.Calculate Grade
4.Exit the program.
*/

#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int rollNumber;
    float marks;
    char grade;
public:
    void setName(string n) {
        name = n;
    }
    void setRollNumber(int r) {
        rollNumber = r;
    }
    void setMarks(float m) {
        marks = m;
    }
    void setGrade(char g) {
        grade = g;
    }
    string getName() {
        return name;
    }
    int getRollNumber() {
        return rollNumber;
    }
    float getMarks() {
        return marks;
    }
    char getGrade() {
        return grade;
    }
void calculateGrade() {
        if (marks >= 90 && marks <= 100)
            grade = 'A';
        else if (marks >= 80)
            grade = 'B';
        else if (marks >= 70)
            grade = 'C';
        else if (marks >= 60)
            grade = 'D';
        else
            grade = 'F';
    }
    void displayInfo() {
        cout << "\nStudent Information";
        cout << "\nName: " << name;
        cout << "\nRoll Number: " << rollNumber;
        cout << "\nMarks: " << marks;
        cout << "\nGrade: " << grade << endl;
    }
};
int main() {
    Student s;
    int choice;
    string name;
    int roll;
    float marks;
    do {
        cout << "\n\nMENU";
        cout << "\n1. Accept Information";
        cout << "\n2. Display Information";
        cout << "\n3. Calculate Grade";
        cout << "\n4. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter Name: ";
            cin >> name;
            cout << "Enter Roll Number: ";
            cin >> roll;
            cout << "Enter Marks: ";
            cin >> marks;
            s.setName(name);
            s.setRollNumber(roll);
            s.setMarks(marks);
            break;
        case 2:
            s.displayInfo();
            break;
        case 3:
            s.calculateGrade();
            cout << "Grade calculated successfully!\n";
            break;
        case 4:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);
    return 0;
}