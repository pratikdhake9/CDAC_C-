/*
Q4. You are tasked with creating an Employee Payroll Management System in C++. Your

program should allow the user to perform the following tasks through a interface:
1.Add a new employee:
-Create a class Employee with the following private data members:
-int empID (EmployeeID)
-string empName (EmployeeName)
-double empSalary(Employee Salary)
-Include appropriate getter and setter methods for these data members.
-Ensure that the Employee ID is unique for each employee.
2.Calculate the gross salary for an employee:
-Create a member function calculate GrossSalary in the Employee class.
-The gross salary should be calculated based on the following rules:
-If the employee's salary is less than or equal to 5000, add a 10% bonus.

menu-driven

-If the employee's salary is greater than 5000 but less than or equal to 10000, add a 15% bonus.
-If the employee's salary is greater than10000,add a 20% bonus.
-Display the gross salary for the chosen employee.
3.Display the employee details:
-Create a member function displayEmployeeDetails in the Employee class to display all the details of an employee (ID, Name, Salary, and Gross Salary).
4.Update employee information:
-Allow the user to update the employee's name and salary using setter methods.
5.Exit the program.
*/

#include <iostream>
using namespace std;

class Employee {
private:
    int empID;
    string empName;
    double empSalary;

public:
 
    void setEmpID(int id) { empID = id; }
    void setEmpName(string name) { empName = name; }
    void setEmpSalary(double salary) { empSalary = salary; }

   
    int getEmpID() { return empID; }
    string getEmpName() { return empName; }
    double getEmpSalary() { return empSalary; }

    double calculateGrossSalary() {
        double bonus = 0;

        if (empSalary <= 5000)
            bonus = empSalary * 0.10;
        else if (empSalary <= 10000)
            bonus = empSalary * 0.15;
        else
            bonus = empSalary * 0.20;

        return empSalary + bonus;
    }

   
    void displayEmployeeDetails() {
        cout << "\nEmployee ID: " << empID;
        cout << "\nName: " << empName;
        cout << "\nSalary: " << empSalary;
        cout << "\nGross Salary: " << calculateGrossSalary() << endl;
    }
};

int main() {

    Employee employees[100];   
    int empCount = 0;        
    int choice;

    do {
        cout << "\n\nEMPLOYEE PAYROLL SYSTEM";
        cout << "\n1. Add New Employee";
        cout << "\n2. Calculate Gross Salary";
        cout << "\n3. Display Employee Details";
        cout << "\n4. Update Employee Information";
        cout << "\n5. Exit";
        cout << "\nEnter choice: ";
        cin >> choice;

        switch (choice) {

        case 1: {
            if (empCount >= 100) {
                cout << "Employee limit reached!\n";
                break;
            }

            int id;
            string name;
            double salary;
            bool exists = false;

            cout << "Enter Employee ID: ";
            cin >> id;

            // Check unique ID
            for (int i = 0; i < empCount; i++) {
                if (employees[i].getEmpID() == id) {
                    exists = true;
                    break;
                }
            }

            if (exists) {
                cout << "Employee ID already exists!\n";
                break;
            }

            cout << "Enter Name: ";
            cin >> name;
            cout << "Enter Salary: ";
            cin >> salary;

            employees[empCount].setEmpID(id);
            employees[empCount].setEmpName(name);
            employees[empCount].setEmpSalary(salary);

            empCount++;

            cout << "Employee Added Successfully!\n";
            break;
        }

        case 2: {
            int id;
            cout << "Enter Employee ID: ";
            cin >> id;

            bool found = false;

            for (int i = 0; i < empCount; i++) {
                if (employees[i].getEmpID() == id) {
                    cout << "Gross Salary: "
                         << employees[i].calculateGrossSalary() << endl;
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Employee Not Found!\n";

            break;
        }

        case 3: {
            int id;
            cout << "Enter Employee ID: ";
            cin >> id;

            bool found = false;

            for (int i = 0; i < empCount; i++) {
                if (employees[i].getEmpID() == id) {
                    employees[i].displayEmployeeDetails();
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Employee Not Found!\n";

            break;
        }

        case 4: {
            int id;
            cout << "Enter Employee ID: ";
            cin >> id;

            bool found = false;

            for (int i = 0; i < empCount; i++) {
                if (employees[i].getEmpID() == id) {
                    string newName;
                    double newSalary;

                    cout << "Enter New Name: ";
                    cin >> newName;
                    cout << "Enter New Salary: ";
                    cin >> newSalary;

                    employees[i].setEmpName(newName);
                    employees[i].setEmpSalary(newSalary);

                    cout << "Employee Updated Successfully!\n";
                    found = true;
                    break;
                }
            }

            if (!found)
                cout << "Employee Not Found!\n";

            break;
        }

        case 5:
            cout << "Exiting Program...\n";
            break;

        default:
            cout << "Invalid Choice!\n";
        }

    } while (choice != 5);

    return 0;
}