/*
Q2.Create a C++ program for a simple banking system.You need to implement a class called
1.BankAccount with the following data members:
2.AccountNumber(int): The account number of the bank account.
3.accountHolderName(string): The name of the account holder.
4.balance (double):The current balance in the account.
The BankAccount class should have the following member functions:
1.Getter and Setter Methods:
2.Deposit method: A method that allows the user to deposit money into the account. It should take an amount as a parameter and update the balance accordingly.

3.withdraw method: A method that allows the user to withdraw money from the account. It should take an amount as a parameter and update the balance. Make sure to check if there is sufficient balance before allowing the withdrawal.
4.displayAccountDetails method: A method that displays the account details ( account number, account holder name, and balance).
Now, create a menu-driven program in the `main` function that allows the user to perform the following operations:
1.Deposit money into an existing account.
2.Withdraw money from an existing account.
3.Display the account details.
4.Exit the program.
*/
#include <iostream>
using namespace std;
class BankAccount {
private:
    int accountNumber;
    string accountHolderName;
    double balance;
public:
    void setAccountNumber(int accNo) {
        accountNumber = accNo;
    }
    void setAccountHolderName(string name) {
        accountHolderName = name;
    }
    void setBalance(double bal) {
        balance = bal;
    }
    int getAccountNumber() {
        return accountNumber;
    }
    string getAccountHolderName() {
        return accountHolderName;
    }
    double getBalance() {
        return balance;
    }
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposit Successful!\n";
        } else {
            cout << "Invalid deposit amount!\n";
        }
    }
    void withdraw(double amount) {
        if (amount <= 0) {
            cout << "Invalid withdrawal amount!\n";
        }
        else if (amount > balance) {
            cout << "Insufficient balance!\n";
        }
        else {
            balance -= amount;
            cout << "Withdrawal Successful!\n";
        }
    }
    void displayAccountDetails() {
        cout << "\n--- Account Details ---";
        cout << "\nAccount Number: " << accountNumber;
        cout << "\nAccount Holder Name: " << accountHolderName;
        cout << "\nCurrent Balance: " << balance << endl;
    }
};
int main() {
    BankAccount account;
    int choice;
    double amount;
    account.setAccountNumber(1001);
    account.setAccountHolderName("Pratik");
    account.setBalance(5000);
    do {
        cout << "\n\nBANK MENU";
        cout << "\n1. Deposit Money";
        cout << "\n2. Withdraw Money";
        cout << "\n3. Display Account Details";
        cout << "\n4. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;
        switch (choice) {
        case 1:
            cout << "Enter amount to deposit: ";
            cin >> amount;
            account.deposit(amount);
            break;
        case 2:
            cout << "Enter amount to withdraw: ";
            cin >> amount;
            account.withdraw(amount);
            break;
        case 3:
            account.displayAccountDetails();
            break;
        case 4:
            cout << "Exiting program\n";
        break;
        default:
            cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 4);
    return 0;
}