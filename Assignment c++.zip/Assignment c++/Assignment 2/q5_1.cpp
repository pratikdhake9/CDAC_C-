#include <iostream>
using namespace std;
class Student {
    int rollNo;
    string name;
    float marks;
public:
    Student() {
        rollNo = 0;
        name = "None";
        marks = 0;
    }
    Student(int r,string n,float m) {
        rollNo = r;
        name = n;
        marks = m;
    }
    Student(int rollNo,string name,float marks) {
        this->rollNo = rollNo;
        this->name = name;
        this->marks = marks;
    }
    void display() {
        cout<<rollNo<<" "<<name<<" "<<marks<<endl;
    }
};
int main() {
    Student s1;
    Student s2(1,"Amit",90);
    Student s3(2,"Ravi",85);
    s1.display();
    s2.display();
    s3.display();
    return 0;
}