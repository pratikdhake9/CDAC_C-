#include <iostream>
using namespace std;
int main() {
    int num = 10;
    int *ptr = &num;
    int &ref = num;
    cout<<"Initial value: "<<num<<endl;
    *ptr = 20;
    cout<<"After pointer change: "<<num<<endl;
    ref = 30;
    cout<<"After reference change: "<<num<<endl;
    return 0;
}