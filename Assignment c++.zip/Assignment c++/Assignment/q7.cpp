#include <iostream>
using namespace std;

const float PI = 3.14f;
float circleArea(float radius) {
    return PI * radius * radius;
}
float circlePerimeter(float radius) {
    return 2 * PI * radius;
}
int main() {
    float radius = 7.0f;
    cout.setf(ios::fixed);
    cout.precision(4);
    cout << "Radius: " << radius << endl;
    cout << "Area: " << circleArea(radius) << endl;
    cout << "Perimeter: " << circlePerimeter(radius) << endl;
    return 0;
}