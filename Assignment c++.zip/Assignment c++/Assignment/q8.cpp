#include <iostream>
using namespace std;
int absolute(int n) {
    return (n < 0) ? -n : n;
}

int clamp(int val, int o, int i) {
    return (val < o) ? o : (val > i) ? i : val;
}
int main() {
    int a[] = {-15, 0, 25, -3};
    int b[]  = {-10, -10, -10, 0};
    int c[]  = {10, 10, 10, 5};
    cout << "val   \tlo   \thi    \tabsolute(val)\tclamp(val,lo,hi) \n";
    for (int i = 0; i < 4; i++) {
        cout << a[i] << "\t"
             << b[i] << "\t"
             << c[i] << "\t"
             << absolute(a[i]) << "\t\t"
             << clamp(a[i], b[i], c[i])
             << endl;
    }
    return 0;
}