#include <stdio.h>

int main() {
    float m1, m2, m3, m4, m5;
    float total, percentage;
    char grade;
    printf("Enter marks of 5 subjects:\n");
    scanf("%f %f %f %f %f", &m1, &m2, &m3, &m4, &m5);
    total = m1 + m2 + m3 + m4 + m5;
    percentage = total / 5;
    grade = (percentage >= 75) ? 'A' :(percentage >= 60) ? 'B' :(percentage >= 45) ? 'C' : 'F';
    printf("\nSubject Marks:\n");
    printf("Subject 1: %.2f\n", m1);
    printf("Subject 2: %.2f\n", m2);
    printf("Subject 3: %.2f\n", m3);
    printf("Subject 4: %.2f\n", m4);
    printf("Subject 5: %.2f\n", m5);
    printf("\nTotal Marks: %.2f\n", total);
    printf("Percentage: %.2f%%\n", percentage);
    printf("Grade: %s\n", (grade == 'F') ? "Fail" : (grade == 'A') ? "A" : (grade == 'B') ? "B" : "C");
    return 0;
}